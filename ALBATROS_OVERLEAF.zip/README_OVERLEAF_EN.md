# Overleaf project

Import this ZIP as a new project. Use pdfLaTeX.
Select main_N.tex as the main document for the article, or supplementary_N.tex for the supplement.
Preserve figures/, figures_clean/ and figures_spatial/ in their supplied locations.

Both TeX files include all text, tables and bibliography.
No BibTeX, R, Python or analysis-data files are required.
All 35 referenced figures are included at their original quality.
Both documents compiled successfully with this layout.
Only relative figure paths were adapted; scientific content was not changed.
The selected versions are the two _N files, rather than main.tex and supplementary.tex.
Overleaf generates the compiled PDFs; redundant compiled copies are not included.
The analysis repository is supplied separately in five ZIP parts.
